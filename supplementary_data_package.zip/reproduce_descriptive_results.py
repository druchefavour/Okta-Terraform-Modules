import csv, statistics
from collections import defaultdict
rows=list(csv.DictReader(open("supplementary_timing_observations.csv",newline="",encoding="utf-8")))
rows=[r for r in rows if r["included_in_analysis"].lower()=="true"]
assert len(rows)==96
g=defaultdict(list)
for r in rows:g[(r["task"],r["method"])].append(float(r["elapsed_seconds"]))
tasks=["OIDC Web","OIDC SPA","OIDC M2M","Custom Scope","Custom Claim","Access Policy"]
out=[]
for task in tasks:
 m=g[(task,"Manual console")];t=g[(task,"Terraform provider/API")]
 assert len(m)==len(t)==8
 mm,tm=statistics.mean(m),statistics.mean(t)
 out.append([task,len(m),mm,statistics.stdev(m),len(t),tm,statistics.stdev(t),mm-tm,100*(mm-tm)/mm,mm/tm])
with open("descriptive_results_reproduced.csv","w",newline="") as f:
 w=csv.writer(f);w.writerow(["task","n_manual","manual_mean_s","manual_sd_s","n_terraform","terraform_mean_s","terraform_sd_s","time_saved_s","reduction_pct","speedup_x"]);w.writerows(out)
print(f"Aggregate manual mean: {sum(x[2] for x in out):.6f} s")
print(f"Aggregate Terraform mean: {sum(x[5] for x in out):.6f} s")
print(f"Reported to 3 decimals: {sum(x[5] for x in out):.3f} s")
