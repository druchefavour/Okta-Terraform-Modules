# CSV audit against Table 2

| Task | Manual mean ± SD (s) | Terraform mean ± SD (s) | Result |
|---|---:|---:|---|
| OIDC Web | 90.208 ± 1.127 | 0.392 ± 0.081 | Matches Table 2 task statistics |
| OIDC SPA | 90.532 ± 3.731 | 0.431 ± 0.131 | Matches Table 2 task statistics |
| OIDC M2M | 92.271 ± 3.328 | 0.306 ± 0.088 | Matches Table 2 task statistics |
| Custom Scope | 150.530 ± 2.536 | 1.265 ± 0.055 | Matches Table 2 task statistics |
| Custom Claim | 179.789 ± 1.970 | 2.056 ± 0.067 | Matches Table 2 task statistics |
| Access Policy | 120.760 ± 1.698 | 1.540 ± 0.109 | Matches Table 2 task statistics |

- Observations: **96**.
- Aggregate manual mean: **724.090 s**.
- Aggregate Terraform mean: **5.990000 s**, rounded to **5.990 s**.
- Sum of displayed task means: **5.990 s**.
- Manuscript action: replace **5.991 s** with **5.990 s** throughout unless higher-precision source measurements are available.