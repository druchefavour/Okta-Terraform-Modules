# Supplementary timing data

## Files
- supplementary_timing_observations.csv: 96 accepted observations in long format.
- reproduce_descriptive_results.py: reproduces task means, sample SDs (n-1), savings, reductions, and speed-ups.
- descriptive_results.csv: generated output.
- CSV_Table2_Audit.md: audit and reconciliation.

## Cleaning
- Standardized task labels and capitalization.
- Corrected `custom clim` to `Custom Claim`.
- Reshaped 48 paired run rows to 96 observation rows.
- Preserved all recorded elapsed-time values.

## Run
`python reproduce_descriptive_results.py`

## Timing reconciliation
The sum of the six unrounded Terraform task means is 5.990000 s, which rounds to 5.990 s. The sum of the six displayed three-decimal task means is 5.990 s. Therefore, 5.990 s is supported by the CSV; 5.991 s is not reproduced by these values.

## De-identification
No tenant URLs, credentials, resource IDs, operator identifiers, or environment names are included.
